<?php

/**
 * Class swoole_server_port
 */
class swoole_server_port
{
    /**
     * @param $event_name
     * @param callable $callback
     */
    function on($event_name, callable $callback)
    {

    }

    /**
     * @param $setting
     */
    function set($setting)
    {

    }
}