<?php
/**
 * Created by PhpStorm.
 * User: yf
 * Date: 2017/1/22
 * Time: 下午9:46
 */
require_once 'Core/Core.php';
\Core\Core::getInstance()->frameWorkInitialize();