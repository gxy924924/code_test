<?php

/**
 * Created by PhpStorm.
 * User: yf
 * Date: 2017/6/13
 * Time: 下午8:01
 */
namespace Core\Http\Message;

class Stream extends \Core\Component\IO\Stream
{
}